import json
from fractions import Fraction as F
from pathlib import Path
r=Path(__file__).resolve().parent
code=(r/'X674_interval_reference.py').read_text().split('max_res=F(0)')[0]
exec(compile(code,'independent_interval_reference','exec'),globals())
T=1<<1100
s0=alt_series
def alt_series(y,mode,terms=100):return s0(y,mode,terms)
ref=json.load(open(r/'X663_terminal_gradient_report.json'))
def state(n):return [val(float(data[n][c])) for c in cols]
def radius(x):
 return plus(I(p['r0']+p['p1']*x[4]+p['p2']*x[5]),plus(scalar(p['p3'],trig(x[0])[1]),scalar(p['p4'],trig(x[1])[0])))
a=radius(state(1318));b=radius(state(1754))
gap=minus(minus(a,b),I(val(0.02)))
lo=F(ref['independent_gap_lower']);hi=F(ref['independent_gap_upper'])
print('GAP_TRUE_IN_X663_BOUND',lo<=gap[0] and gap[1]<=hi)
print('GAP_LOWER_MARGIN',float(gap[0]-lo)); print('GAP_UPPER_MARGIN',float(hi-gap[1]))
x=state(1754)
grad=[scalar(-p['p3'],trig(x[0])[0]),scalar(p['p4'],trig(x[1])[1]),I(0),I(0),I(p['p1']),I(p['p2']),I(0)]
ok=0
for i in range(7):
 l,h=map(F,ref['terminal_gradient_intervals'][i]); u,v=grad[i]
 if l<=u and v<=h:ok+=1
 else:print('GRAD_INTERVAL_NOT_CONTAINED',i,float(l-u),float(v-h))
print('TERMINAL_GRADIENT_COMPONENTS_CONTAINED',ok,'/7')
