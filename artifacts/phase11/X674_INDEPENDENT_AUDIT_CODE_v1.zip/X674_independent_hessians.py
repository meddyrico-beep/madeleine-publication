"""Independent full-box Hessian upper bounds vs exported X672 remainders.
Direct position formula, separate analytic acceleration evaluation at exact reference.
Pure fractions and rigorous alternating-series trig/exp intervals; not importing X670.
"""
import json,zipfile,csv,io,ast,hashlib
from fractions import Fraction as F
from pathlib import Path
root=Path(__file__).resolve().parent
code=(root/'X674_interval_reference.py').read_text().split('max_res=F(0)')[0]
exec(compile(code,'independent_interval_reference','exec'),globals())
T=1<<640
s0=alt_series
def alt_series(y,mode,terms=100):return s0(y,mode,terms)
w=json.loads((root/'X672_induction_witness.json').read_text())
ref=json.loads((root/'X661_dyadic_witness.json').read_text())
S=1<<256
K=((1,-1,0,0,0,0,0),(0,0,1,-1,0,0,0),(0,0,0,0,0,0,1))
kap=(p['kappa1'],p['kappa2'],p['kappa3'])
viol=0;first=None;max_deficit=0;min_comp_slack=None;checked=0;raw_pos=0
min_in=None;min_inloc=None
for k in range(436):
 n=1318+k; x=[val(float(data[n][c])) for c in cols]
 assert all(F(ref['reference_states'][k][i][0])==x[i] for i in range(7))
 b=[F(int(Bi),S) for Bi in w['boxes_grid'][k]]
 q=x[0]-x[1];u=x[2]-x[3];z=x[6]-p['dt_star']
 y=[(q-b[0]-b[1],q+b[0]+b[1]),(u-b[2]-b[3],u+b[2]+b[3]),(z-b[6],z+b[6])]
 for idx,lo,hi in [(0,F(0),F(10**20)),(2,F(-10**20),F(10**20)),(3,F(-10**20),F(10**20)),(5,F(0),F(1)),(6,p['dt_min'],p['dt_max'])]:
  a,bmin=(y[0] if idx==0 else (x[idx]-b[idx],x[idx]+b[idx]))
  if idx in (0,2,3): m=min(abs(a),abs(bmin)); assert a>0 or bmin<0
  else: m=min(a-lo,hi-bmin); assert m>0
  if min_in is None or m<min_in:min_in=m;min_inloc=(n,idx)
 dmax=max(abs(x[6]-b[6]),abs(x[6]+b[6]))
 sn,cs=trig(x[1]-x[0]); st,ct=trig(x[0])
 absupper=lambda v:max(abs(v[0]),abs(v[1]))
 sd=min(F(1),absupper(sn)+b[0]+b[1]);cd=min(F(1),absupper(cs)+b[0]+b[1])
 stmax=min(F(1),absupper(st)+b[0]);ctmax=min(F(1),absupper(ct)+b[0])
 gt=[p['alpha_tau']+p['gamma_tau']*cd,p['gamma_tau']*cd,p['beta_tau'],F(0),p['mu_tau'],p['nu_tau'],F(0)]
 gc=[p['gamma_chi']*ctmax,p['alpha_chi']+p['sigma_chi'],F(0),p['beta_chi'],p['mu_chi'],p['nu_chi'],F(0)]
 ft=trig(p['omega_tau']*n)[0];fc=trig(p['omega_chi']*n)[1]
 At=plus(I(-p['alpha_tau']*x[0]-p['beta_tau']*x[2]+p['mu_tau']*x[4]+p['nu_tau']*x[5]),plus(scalar(p['gamma_tau'],sn),scalar(p['eps_tau'],ft)))
 Ac=plus(I(-p['alpha_chi']*x[1]-p['beta_chi']*x[3]-p['sigma_chi']*(x[1]-p['chi_star'])+p['mu_chi']*x[4]-p['nu_chi']*(1-x[5])),plus(scalar(p['gamma_chi'],st),scalar(p['eps_chi'],fc)))
 Atmax=absupper(At)+sum((gt[i]*b[i] for i in range(7)),F(0))
 Acmax=absupper(Ac)+sum((gc[i]*b[i] for i in range(7)),F(0))
 minabs=lambda v: F(0) if v[0]<=0<=v[1] else min(abs(v[0]),abs(v[1]))
 smin=sum((kap[j]*minabs(y[j])**2 for j in range(3)),F(0))
 Emax=min(F(1),expnegative(smin)[1])
 sm=[sum((kap[l]*abs(K[l][a])*absupper(y[l]) for l in range(3)),F(0)) for a in range(7)]
 hsum=[F(0)]*7
 for a in range(7):
  for bb in range(7):
   ha=p['gamma_tau']*sd if a in (0,1) and bb in (0,1) else F(0)
   hc=p['gamma_chi']*stmax if a==0 and bb==0 else F(0)
   hvt=dmax*ha+(gt[bb] if a==6 else 0)+(gt[a] if bb==6 else 0)
   hvc=dmax*hc+(gc[bb] if a==6 else 0)+(gc[a] if bb==6 else 0)
   # DIRECT hessian of p+=p+dv+d² A, independent of nested X670 calculation
   ht=dmax**2*ha +2*dmax*((gt[bb] if a==6 else 0)+(gt[a] if bb==6 else 0)) + (2*Atmax if a==6 and bb==6 else 0) + (1 if (a,bb) in [(6,2),(2,6)] else 0)
   hh=dmax**2*hc +2*dmax*((gc[bb] if a==6 else 0)+(gc[a] if bb==6 else 0)) + (2*Acmax if a==6 and bb==6 else 0) + (1 if (a,bb) in [(6,3),(3,6)] else 0)
   Kab=sum((kap[l]*K[l][a]*K[l][bb] for l in range(3)),F(0))
   he=(1-p['lam'])*Emax*(4*sm[a]*sm[bb]+2*abs(Kab))
   hd=6*p['dt_cubic']*absupper(y[2]) if a==6 and bb==6 else F(0)
   H=[ht,hh,hvt,hvc,F(0),he,hd]
   for i in range(7):hsum[i]+=H[i]*b[a]*b[bb]
 for i in range(7):
  rem=F(1,5000000000000000)+hsum[i]/2
  maxgrid=-( (-rem.numerator*S)//rem.denominator)
  # ceil rather than nearest or tolerance
  stored=w['defects_grid'][k][i]
  checked+=1
  if maxgrid>stored:
   viol+=1
   excess=maxgrid-stored
   if first is None:first=(n,i,int(excess))
   max_deficit=max(max_deficit,excess)
  slack=stored-maxgrid
  if min_comp_slack is None or slack<min_comp_slack:min_comp_slack=slack
 if (k+1)%100==0 or k==435:print('HESSIAN_CHECKPOINT',n,'REMAINDER_VECTORS',k+1,'VIOLATIONS',viol,flush=True)
print('HESSIAN_BOUND_TESTS',149548)
print('COMPONENT_REMAINDER_ENCLOSURES',checked)
print('BOUND_VIOLATIONS',viol)
print('FIRST_VIOLATION',first)
print('WORST_EXCESS_GRID',max_deficit)
print('MINIMUM_REMAINDER_SLACK_GRID',min_comp_slack)
print('MINIMUM_INPUT_BRANCH_MARGIN',float(min_in),min_inloc)
