from pathlib import Path
"""Independent exact-rational interval evaluation of the reference orbit residuals.
Taylor alternating enclosure order 24; dyadic outward grid 2^-256 after angle doubling.
No imports of the X670 checker or its data-generating logic."""
import ast,zipfile,csv,io,hashlib, json
from fractions import Fraction as F
from pathlib import Path
r=Path(__file__).resolve().parent
# sanity reference exact values
w=json.loads((r/'X661_dyadic_witness.json').read_text())
cols=('tau','chi','vtau','vchi','mem','coh','dt')
with zipfile.ZipFile(r/'D4-D10.zip') as z:
 data=list(csv.DictReader(io.StringIO(z.read('d5_native_v06/series.csv').decode())))
T=1<<256
ZERO=F(0); ONE=F(1)
def val(v):
 a,b=v.as_integer_ratio() if type(v)==float else (v,1)
 return F(a,b)
source=ast.parse((r/'d5_native_lab.py').read_text())
cls=next(n for n in source.body if isinstance(n,ast.ClassDef) and n.name=='D5Config')
p={n.target.id:ast.literal_eval(n.value) for n in cls.body if isinstance(n,ast.AnnAssign) and n.value is not None}
preset=next(n for n in source.body if isinstance(n,ast.FunctionDef) and n.name=='preset_d5_v06')
call=next(n for n in ast.walk(preset) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='D5Config')
p.update({k.arg:ast.literal_eval(k.value) for k in call.keywords})
p={k:val(v) for k,v in p.items() if type(v) in (float,int)}
def I(a,b=None):
 a=F(a); b=F(a if b is None else b)
 assert a<=b; return (a,b)
def plus(x,y):return (x[0]+y[0],x[1]+y[1])
def minus(x,y):return (x[0]-y[1],x[1]-y[0])
def times(x,y):
 arr=(x[0]*y[0],x[0]*y[1],x[1]*y[0],x[1]*y[1]);return(min(arr),max(arr))
def neg(x):return(-x[1],-x[0])
def scalar(a,x):return times(I(a),x)
def outward(x):
 lo=x[0].numerator*T//x[0].denominator
 hi=-((-x[1].numerator*T)//x[1].denominator)
 return I(F(lo,T),F(hi,T))
def alt_series(y,mode,terms=24):
 assert ZERO<=y<=F(1,2)
 curr=ONE if mode!='sin' else y
 s=ZERO
 for k in range(terms):
  s+=curr
  if mode=='sin':curr*= -y*y/F((2*k+2)*(2*k+3))
  elif mode=='cos':curr*= -y*y/F((2*k+1)*(2*k+2))
  elif mode=='exp':curr*= -y/F(k+1)
  else:raise RuntimeError(mode)
 assert curr>=0
 return outward(I(s,s+curr))
def trig(x):
 sign=1 if x>=0 else -1
 y=abs(x);half=0
 while y>F(1,2):y/=2;half+=1
 sn=alt_series(y,'sin');cs=alt_series(y,'cos')
 for _ in range(half):
  sn,cs=outward(scalar(2,times(sn,cs))),outward(minus(scalar(2,times(cs,cs)),I(1)))
 return (neg(sn) if sign<0 else sn),cs
def expnegative(x):
 assert x>=0
 half=0
 while x>F(1,2):x/=2;half+=1
 e=alt_series(x,'exp')
 for _ in range(half):e=outward(times(e,e))
 return e

def realstep(a,n):
 t,c,v,w,m,h,d=a
 sing=trig(c-t)[0]
 force_t=trig(p['omega_tau']*n)[0]
 force_c=trig(p['omega_chi']*n)[1]
 sin_t=trig(t)[0]
 At=plus(I(-p['alpha_tau']*t-p['beta_tau']*v+p['mu_tau']*m+p['nu_tau']*h), plus(scalar(p['gamma_tau'],sing),scalar(p['eps_tau'],force_t)))
 Ac=plus(I(-p['alpha_chi']*c-p['beta_chi']*w-p['sigma_chi']*(c-p['chi_star'])+p['mu_chi']*m-p['nu_chi']*(1-h)), plus(scalar(p['gamma_chi'],sin_t),scalar(p['eps_chi'],force_c)))
 vn=plus(I(v),scalar(d,At));wn=plus(I(w),scalar(d,Ac))
 tn=plus(I(t),scalar(d,vn));cn=plus(I(c),scalar(d,wn))
 mn=I(p['rho']*m+p['a_m']*h+p['b_m']*abs(t-c)+p['c_m']*(abs(v)+abs(w)))
 en=times(times(expnegative(p['kappa1']*(t-c)**2),expnegative(p['kappa2']*(v-w)**2)), expnegative(p['kappa3']*(d-p['dt_star'])**2))
 hn=plus(I(p['lam']*h),scalar(1-p['lam'],en))
 dn=I(d+p['eta_t']*(p['u1']*(h-p['dt_bias'])-p['u2']*abs(t-c)-p['u3']*(abs(v)+abs(w))-p['u4']*(d-p['dt_star']))-p['dt_cubic']*(d-p['dt_star'])**3)
 return [tn,cn,vn,wn,mn,hn,dn]
max_res=F(0); worst=None; minbranch=(None,None)
for n in range(1318,1754):
 a=[val(float(data[n][c])) for c in cols];b=[val(float(data[n+1][c])) for c in cols]
 assert all(a[i]==F(w['reference_states'][n-1318][i][0]) for i in range(7)), 'ref mismatch'
 y=realstep(a,n)
 for i,(lo,hi) in enumerate(y):
  err=max(abs(lo-b[i]),abs(hi-b[i]))
  if err>max_res:max_res=err;worst=(n,cols[i])
 for ci,L,U in [(5,F(0),F(1)),(6,p['dt_min'],p['dt_max'])]:
  margin=min(y[ci][0]-L,U-y[ci][1]);assert margin>0
  if minbranch[0] is None or margin<minbranch[0]:minbranch=(margin,(n,cols[ci]))
 if (n-1317)%100==0 or n==1753:print('PASS_CHECKPOINT',n+1,flush=True)
print('EXACT_RATIONAL_INTERVAL_REFERENCE_RESIDUAL_MAX',float(max_res))
print('EXACT_RATIONAL_INTERVAL_REFERENCE_RESIDUAL_WORST',worst)
print('RHO_2E_16_ENCLOSURE_PASS', max_res<F(2,10**16))
print('MIN_RAW_REFERENCE_OUTPUT_MARGIN',float(minbranch[0]),minbranch[1])
