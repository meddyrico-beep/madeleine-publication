import sympy as s
T,C,V,W,M,H,D = x = s.symbols('tau chi vtau vchi m coh dt', real=True)
alpha,beta,gamma,mu,nu,delta = s.symbols('a b g mu nu delta', real=True)
q=T-C; u=V-W; z=D-delta
# Hessian algebra independent checks for positions and velocity, with A depending only on x[:6]
A=-alpha*T-beta*V+gamma*s.sin(C-T)+mu*M+nu*H
vnext=V+D*A
pnext=T+D*vnext
H_A=s.hessian(A,x); H_v=s.hessian(vnext,x); H_p=s.hessian(pnext,x)
ei=lambda i: s.Matrix([int(j==i) for j in range(7)])
e6=ei(6); e2=ei(2)
expected_v=D*H_A + e6*s.Matrix([s.diff(A,a) for a in x]).T+s.Matrix([s.diff(A,a) for a in x])*e6.T
expected_p=D*expected_v + e6*s.Matrix([s.diff(vnext,a) for a in x]).T+s.Matrix([s.diff(vnext,a) for a in x])*e6.T
assert H_v.equals(expected_v)
assert H_p.equals(expected_p)
# clock cubic
kc=s.symbols('kc')
clock=D-kc*z**3
Cclock=s.hessian(clock,x)
assert s.simplify(Cclock[6,6] +6*kc*z)==0
assert all(Cclock[i,j]==0 for i in range(7) for j in range(7) if (i,j)!=(6,6))
# exp hessian identity
k1,k2,k3=s.symbols('k1 k2 k3',positive=True)
E=s.exp(-k1*q*q-k2*u*u-k3*z*z)
Y=[q,u,z]; ks=[k1,k2,k3]
Sigma=[sum(ks[l]*Y[l]*s.diff(Y[l],x[a]) for l in range(3)) for a in range(7)]
for a in range(7):
 for b in range(7):
  K=sum(ks[l]*s.diff(Y[l],x[a])*s.diff(Y[l],x[b]) for l in range(3))
  assert s.simplify(s.diff(E,x[a],x[b])-E*(4*Sigma[a]*Sigma[b]-2*K))==0,(a,b)
print('POSITION_HESSIANS: SYMBOLIC_PASS')
print('VELOCITY_HESSIANS: SYMBOLIC_PASS')
print('COHERENCE_HESSIAN_IDENTITIES: 49_PASS')
print('CLOCK_CUBIC_HESSIAN: SYMBOLIC_PASS')
