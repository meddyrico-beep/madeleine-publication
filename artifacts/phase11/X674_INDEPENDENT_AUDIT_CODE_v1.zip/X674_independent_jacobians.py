import ast,zipfile,csv,io,hashlib,json
from fractions import Fraction as F
from pathlib import Path
r=Path(__file__).resolve().parent
# reuse independently implemented exact interval functions, without executing its diagnostic body
code=(r/'X674_interval_reference.py').read_text().split('max_res=F(0)')[0]
exec(compile(code,'independent_interval_reference','exec'),globals())
T=1<<640
oldseries=alt_series
def alt_series(y,mode,terms=100):return oldseries(y,mode,terms)
N=436
JD=json.loads((r/'X665_independent_jacobians.json').read_text())['jacobians']
D=7
zero=I(0);one=I(1)
def partial_jac(a,n):
 t,c,v,w,m,h,d=a
 q=t-c; u=v-w; z=d-p['dt_star']
 sin_diff,cos_diff=trig(c-t)
 sin_tau,cos_tau=trig(t)
 tforce=trig(p['omega_tau']*n)[0];cforce=trig(p['omega_chi']*n)[1]
 At=plus(I(-p['alpha_tau']*t-p['beta_tau']*v+p['mu_tau']*m+p['nu_tau']*h),plus(scalar(p['gamma_tau'],sin_diff),scalar(p['eps_tau'],tforce)))
 Ac=plus(I(-p['alpha_chi']*c-p['beta_chi']*w-p['sigma_chi']*(c-p['chi_star'])+p['mu_chi']*m-p['nu_chi']*(1-h)),plus(scalar(p['gamma_chi'],sin_tau),scalar(p['eps_chi'],cforce)))
 dAt=[minus(I(-p['alpha_tau']),scalar(p['gamma_tau'],cos_diff)),scalar(p['gamma_tau'],cos_diff),I(-p['beta_tau']),zero,I(p['mu_tau']),I(p['nu_tau']),zero]
 dAc=[scalar(p['gamma_chi'],cos_tau),I(-p['alpha_chi']-p['sigma_chi']),zero,I(-p['beta_chi']),I(p['mu_chi']),I(p['nu_chi']),zero]
 V=plus(I(v),scalar(d,At));W=plus(I(w),scalar(d,Ac))
 dV=[plus(plus((one if j==2 else zero),scalar(d,dAt[j])),(At if j==6 else zero)) for j in range(D)]
 dW=[plus(plus((one if j==3 else zero),scalar(d,dAc[j])),(Ac if j==6 else zero)) for j in range(D)]
 dt=[plus(plus((one if j==0 else zero),scalar(d,dV[j])),(V if j==6 else zero)) for j in range(D)]
 dc=[plus(plus((one if j==1 else zero),scalar(d,dW[j])),(W if j==6 else zero)) for j in range(D)]
 s1=1 if q>0 else -1; s2=1 if v>0 else -1; s3=1 if w>0 else -1
 dm=[I(p['b_m']*s1),I(-p['b_m']*s1),I(p['c_m']*s2),I(p['c_m']*s3),I(p['rho']),I(p['a_m']),zero]
 kvals=(p['kappa1'],p['kappa2'],p['kappa3'])
 y=(q,u,z); U=((1,-1,0,0,0,0,0),(0,0,1,-1,0,0,0),(0,0,0,0,0,0,1))
 expo=expnegative(sum((k*yv*yv for k,yv in zip(kvals,y)),F(0)))
 dh=[]
 for j in range(D):
  Sj=sum((kvals[l]*y[l]*U[l][j] for l in range(3)),F(0))
  dh.append(plus((I(p['lam']) if j==5 else zero),scalar(-2*(1-p['lam'])*Sj,expo)))
 dd=[I(-p['eta_t']*p['u2']*s1),I(p['eta_t']*p['u2']*s1),I(-p['eta_t']*p['u3']*s2),I(-p['eta_t']*p['u3']*s3),zero,I(p['eta_t']*p['u1']),I(1-p['eta_t']*p['u4']-3*p['dt_cubic']*z*z)]
 return [dt,dc,dV,dW,dm,dh,dd]
viol=0;max_exc=F(0);first=None;checked=0
for n in range(1318,1754):
 a=[val(float(data[n][c])) for c in cols]
 J=partial_jac(a,n)
 for i in range(D):
  for j in range(D):
   lower,upper=map(F,JD[n-1318][i][j]);c,d=J[i][j];checked+=1
   if c<lower or d>upper:
    viol+=1
    if first is None:first=(n,i,j,str(lower),str(upper),str(c),str(d))
    max_exc=max(max_exc,lower-c,d-upper)
 if n in (1417,1517,1617,1717,1753):print('JACOBIAN_CHECKPOINT',n+1,checked,'violations',viol,flush=True)
print('INDEPENDENT_JACOBIAN_ENCLOSURES',checked)
print('ENCLOSURES_NOT_CONTAINED',viol)
print('FIRST_VIOLATION',first and first[:3])
print('MAX_EXCESS',float(max_exc))
