# Independent analytical audit scripts for F11-CORE-031.X.6.7.4

These are newly authored review programs, NOT the frozen X670 source.
Use Python 3.11+ (no third-party packages required except SymPy for the optional symbolic audit).
Place the five .py files in the folder containing the 16 extracted entries from
X674_ANALYTIC_REVIEW_INPUTS_v1.zip. Run in this order:

python X674_interval_reference.py
python X674_independent_jacobians.py
python X674_independent_terminal.py
python X674_independent_hessians.py
python X674_symbolic_derivatives.py   # optional, requires sympy

Each audit reconstructs evidence from the D5 source and archived reference
without importing X670 or X673b. Rational alternating-series intervals enclose
transcendental functions. The 436-step Jacobian and Hessian audits may be slow.

Scope: mathematical exact-real D5 Native v0.6 with binary64-valued constants;
not automatically an IEEE-754 perturbed-execution roundoff certificate.
All claims and hashes should be independently assessed before external publication.
